import akka.actor.{ActorSystem, Props}
import com.typesafe.config.ConfigFactory

object ServiceMembersLookup extends App{
  //Load the configuration of application.conf
  val configuration = ConfigFactory.load.getConfig("ServiceMembersLookup")
  //Create an actor of system
  val system = ActorSystem("ServiceMembersLookup", configuration)
  //Select an actor with his remote path
  //The path is formed by the hostname, port and followed by the node address



  //Create an actor of type Worker
  val worker = system.actorSelection("akka.tcp://ServiceMembers@127.0.0.1:2552/user/worker-remote")
  worker ! Trabajador_Ex_3.Worker("Hello remote!")
}
