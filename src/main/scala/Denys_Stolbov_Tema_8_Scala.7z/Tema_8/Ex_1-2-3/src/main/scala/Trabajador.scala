import akka.actor.Actor

object Trabajador {
  case class Worker()
}

class Trabajador extends Actor {
  import Trabajador._
  /*
  def recieve={
    case message: Worker => println(s"Have sent a messsage and my Actorref is ${self}.")
  }
  */
  override def receive: Receive = {
    case message: Worker => println(s"Have sent a messsage and my Actorref is ${self}.")
  }
}


