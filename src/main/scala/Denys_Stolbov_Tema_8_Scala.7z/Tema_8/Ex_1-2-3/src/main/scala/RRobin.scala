import Trabajador._
import akka.actor.{ActorSystem, Props}
import akka.routing.{FromConfig, RoundRobinPool}

object RoundRobin extends App {
  val system = ActorSystem("Round-Robin-Router")
  val tableRout = system.actorOf(RoundRobinPool(4).props(Props[Trabajador]), "round-robin-pool")
  tableRout ! Worker()
  tableRout ! Worker()
  tableRout ! Worker()
  Thread.sleep(100)

  system.actorOf(Props[Trabajador], "t1")
  system.actorOf(Props[Trabajador], "t2")
  system.actorOf(Props[Trabajador], "t3")

  val GroupRout = system.actorOf(FromConfig.props, "round-robin-group")

  GroupRout ! Worker()
  GroupRout ! Worker()
  GroupRout ! Worker()
  Thread.sleep(100)
  system.terminate()
}
