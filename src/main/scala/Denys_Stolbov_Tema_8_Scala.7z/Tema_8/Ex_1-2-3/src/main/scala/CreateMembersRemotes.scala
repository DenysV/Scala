import akka.actor.{ActorSystem, Props}
import com.typesafe.config.ConfigFactory

object CreateMembersRemotes extends App{
  //Load the configuration of application.conf
  val configuration = ConfigFactory.load.getConfig("CreateMembersRemotes")
  //Create an actor of system
  val system = ActorSystem("CreateMembersRemotes", configuration)
  //Create an actor of type Worker
  val workerActor = system.actorOf(Props[Trabajador_Ex_3], "worker-actor-remote")
  println(s"A path of an actor worker is ${workerActor.path}")
  workerActor ! Trabajador_Ex_3.Worker("Hello worker remote!")
}
