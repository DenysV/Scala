import akka.actor.{ActorSystem, Props}
import com.typesafe.config.ConfigFactory

object ServiceMembers extends App{
  //Load the configuration of application.conf
  val configuration = ConfigFactory.load.getConfig("ServiceMembers")
  //Create an actor of system
  val system = ActorSystem("ServiceMembers", configuration)
  //Create an actor of type Worker
  val worker = system.actorOf(Props[Trabajador_Ex_3], "worker-remote")
  println(s"A path of an actor worker is ${worker.path}")
}
