import akka.actor.Actor

object Trabajador_Ex_3 {
  case class Worker(message: String)
}

class Trabajador_Ex_3 extends Actor {
  import Trabajador._
  override def receive: Receive = {
    case message: Worker =>
      println(s"Worker: have sent a messsage and my Actorref is ${self}.")
      println(s"Worker: content of message is ${message}.")
  }
}