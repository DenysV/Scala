import Almacenamiento.AnadirUsuario
import Comprobador.{ComprobarUsuario, UsuarioBueno, UsuarioIntruso}
import Recorder.NuevoUsuario
import akka.actor.{Actor, ActorRef, ActorSystem, Props}
import akka.pattern.ask
import akka.util.Timeout

import scala.concurrent.duration._
import scala.language.postfixOps

case class Usuario(username: String, email: String)

object Recorder{
  sealed trait RecorderMsg
  case class NuevoUsuario(user: Usuario) extends RecorderMsg
}

object Comprobador{
  sealed trait ComprobarMsg
  case class ComprobarUsuario(user: Usuario) extends ComprobarMsg

  sealed trait ComprobarRequest
  case class UsuarioIntruso(user: Usuario) extends ComprobarMsg
  case class UsuarioBueno(user: Usuario) extends ComprobarMsg
}

object Almacenamiento{
  sealed trait AlmacenamientoMsg
  case class AnadirUsuario(user: Usuario) extends AlmacenamientoMsg
}

class Recorder(comprobador: ActorRef, almacenamiento: ActorRef) extends Actor{
  import scala.concurrent.ExecutionContext.Implicits.global
  implicit val timeout = Timeout(5 seconds)

  def receive = {
    case NuevoUsuario(usuario) =>
      comprobador ? ComprobarUsuario(usuario) map {
        case UsuarioBueno(usuario) =>
          almacenamiento ! AnadirUsuario(usuario)
        case UsuarioIntruso(usuario) =>
          println(s"Recorder: $usuario en la lista negra")
      }
  }
}

class Almacenamiento extends Actor{
  var usuarios = List.empty[Usuario]
  def receive = {
    case AnadirUsuario(user) =>
      println(s"Almacenamiento: $user anadido")
      usuarios = user :: usuarios
  }
}

class Comprobador extends Actor{
  val blackList = List(Usuario("Denys","Denys@gmail.com"))

  def receive = {
    case ComprobarUsuario(usuario) if blackList.contains(usuario) =>
      println(s"Comprobar: $usuario en la list negra")
      sender() ! UsuarioIntruso(usuario)

    case ComprobarUsuario(usuario) =>
      println(s"Comprobador: $usuario noesta en la lista negra")
      sender() ! UsuarioBueno(usuario)
  }
}


object Comunicacion extends App{
  val system = ActorSystem("comunication-con-actores")
  val comprobador = system.actorOf(Props[Comprobador], "comprobador")
  val almacenamiento = system.actorOf(Props[Almacenamiento], "almacenamiento")
  val recorder = system.actorOf(Props(new Recorder(comprobador, almacenamiento)), "recorder")

  recorder ! Recorder.NuevoUsuario(Usuario("Alex", "alex@gmail.com"))
  recorder ! Recorder.NuevoUsuario(Usuario("Alfred", "alfred@gmail.com"))
  recorder ! Recorder.NuevoUsuario(Usuario("Andrew", "andrew@gmail.com"))

  Thread.sleep(100)
  println("Hasta luego!")
  system.terminate()
}