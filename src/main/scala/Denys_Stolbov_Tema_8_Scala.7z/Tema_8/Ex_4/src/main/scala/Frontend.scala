package com.packt.akka.cluster
import akka.cluster._
import scala.util.Random
import com.typesafe.config.ConfigFactory
import akka.actor.{Actor, ActorRef, ActorSystem, Props, Terminated}
import cluster.{Add, BackendRegistro}

class Frontend extends Actor {
  var backends = IndexedSeq.empty[ActorRef]
  def receive= {
    case Add if backends.isEmpty =>
      println("Innacesible service, the cluster does not have a backend active.")
    case addOp: Add =>
      println("Frontend: Send operation 'add' to the backend for treatment.")
      backends(Random.nextInt(backends.size)) forward addOp
    case BackendRegistro if !backends.contains(sender()) =>
      backends = backends :+ sender()
      context watch(sender())
    case Terminated(a) =>
      backends = backends.filterNot(_ == a)
  }
}

object Frontend {
  private var _frontend: ActorRef = _
  def iniciar() = {
    val config = ConfigFactory.load().getConfig("Frontend")
    val system = ActorSystem("ClusterSystem", config)
    _frontend = system.actorOf(Props[Frontend], name = "frontend")
  }
  def getFrontend = _frontend
}
