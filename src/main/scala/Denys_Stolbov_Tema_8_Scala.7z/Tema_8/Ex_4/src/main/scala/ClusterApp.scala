package com.pakt.akka.cluster

import cluster.Add
import com.packt.akka.cluster._

object ClusterApp extends App{
  //Initialization of frontend
  Frontend.iniciar()
  //Initialization of 3 nodes of backend
  Backend.iniciar(2552)
  Backend.iniciar(2560)
  Backend.iniciar(2561)
  Thread.sleep(10000)
  //Add operation
  Frontend.getFrontend ! Add(1, 3)
}
