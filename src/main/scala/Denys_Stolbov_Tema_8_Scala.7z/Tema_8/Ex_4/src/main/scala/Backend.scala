package com.pakt.akka.cluster
import akka.actor.{Actor, ActorSystem, Props, RootActorPath}
import akka.cluster.Cluster
import akka.cluster.ClusterEvent.MemberUp
import cluster.{Add, BackendRegistro}
import com.typesafe.config.ConfigFactory

class Backend extends  Actor{
  val cluster = Cluster(context.system)
  //Subscribe to the changes in the cluster, MemberUp
  // Re-subscribe when it restarts
  override def preStart()={
    cluster.subscribe(self, classOf[MemberUp])
  }
  override def postStop()={
    cluster.unsubscribe(self)
  }
  def receive = {
    //Add operation
    case Add(num1, num2) =>
      println(s"I am a backend with the path: ${self} and I have received a operation.")
    case MemberUp(member) =>
      if (member.hasRole("frontend")){
        context.actorSelection(RootActorPath(member.address)/"user"/"frontend")!BackendRegistro
      }
  }
}

object Backend {
  def iniciar(port: Int) = {
    //Configuration for the backend from the archive
    //configuration and the port on which you want to initialize
    val config = ConfigFactory.parseString(s"akka.remote.netty.tcp.port = $port.").
      withFallback(ConfigFactory.load().getConfig("Backend"))
    val system = ActorSystem("ClusterSystem", config)
    //Create backend actor
    val Backend = system.actorOf(Props[Backend], name="Backend")
  }
}
