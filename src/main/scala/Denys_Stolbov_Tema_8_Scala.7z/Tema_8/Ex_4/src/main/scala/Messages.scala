package cluster
case class Add(num1: Int, num2: Int)
case object BackendRegistro